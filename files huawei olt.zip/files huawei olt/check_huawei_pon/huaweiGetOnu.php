<?php
include("funcoeshuawei_onu.php");


$serial = huawei_getall_onu_serial('', '');
$nome   = huawei_getall_onu_nomes('', '');
$power  = huawei_getall_onu_powerlevel('', '');
// $power_olt = huawei_getall_olt_powerlevel('', '');
$distance = huawei_getall_onu_distance('', '');
$status = huawei_getall_onu_status('', '');


$result = array();
$arr = array();
$len = count($nome);
$row = array();

for ($i = 0; $i < $len; $i++) {
       $row["serial"] = $serial[$i][1];
       $row["nome"] = $nome[$i];
       $row["status"] = $status[$i];
       $row["power"] = $power[$i];
       // $row["power_olt"] = $power_olt[$i];
       $row["distance"] = $distance[$i];
       array_push($result, $row);
}

var_dump($result);
